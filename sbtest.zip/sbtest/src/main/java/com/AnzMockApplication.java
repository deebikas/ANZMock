package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnzMockApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnzMockApplication.class, args);
	}

}
